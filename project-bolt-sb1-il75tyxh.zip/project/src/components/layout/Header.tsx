import { ShieldCheck, Home, FileText, FolderOpen, LifeBuoy, Info } from 'lucide-react';
import type { Page } from '@/types';

interface HeaderProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const navItems: { page: Page; label: string; icon: typeof Home }[] = [
  { page: 'home', label: 'Home', icon: Home },
  { page: 'report', label: 'Report an Issue', icon: FileText },
  { page: 'my-reports', label: 'My Reports', icon: FolderOpen },
  { page: 'safety', label: 'Safety Center', icon: LifeBuoy },
  { page: 'about', label: 'About', icon: Info },
];

export function Header({ currentPage, onNavigate }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-lg"
          aria-label="CivicBridge AI home"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-sky-700 shadow-sm">
            <ShieldCheck size={20} className="text-white" />
          </div>
          <span className="text-lg font-bold text-slate-900">
            CivicBridge <span className="text-sky-600">AI</span>
          </span>
        </button>

        <nav className="hidden md:flex items-center gap-1" aria-label="Main navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.page}
                  onClick={() => onNavigate(item.page)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                  isActive
                    ? 'bg-sky-50 text-sky-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <nav className="md:hidden" aria-label="Main navigation">
          <select
            value={currentPage}
            onChange={(e) => onNavigate(e.target.value as Page)}
            className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            aria-label="Navigate to page"
          >
            {navItems.map((item) => (
              <option key={item.page} value={item.page}>
                {item.label}
              </option>
            ))}
          </select>
        </nav>
      </div>
    </header>
  );
}
