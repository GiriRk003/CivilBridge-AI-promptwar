import { ShieldCheck, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-sky-700">
              <ShieldCheck size={16} className="text-white" />
            </div>
            <span className="text-sm font-semibold text-slate-700">
              CivicBridge AI
            </span>
          </div>
          <p className="text-xs text-slate-500 text-center sm:text-right">
            AI analysis is not a substitute for emergency services.
            <br className="hidden sm:block" />
            Always contact your local emergency number in life-threatening situations.
          </p>
          <p className="flex items-center gap-1.5 text-xs text-slate-400">
            Built with <Heart size={12} className="text-red-400 fill-red-400" /> for communities
          </p>
        </div>
      </div>
    </footer>
  );
}
