import { Badge } from '@/components/ui/Badge';
import type { VerificationLabel } from '@/types';

interface VerificationTagProps {
  label: VerificationLabel;
}

export function VerificationTag({ label }: VerificationTagProps) {
  return <Badge variant="verification" verification={label} />;
}
