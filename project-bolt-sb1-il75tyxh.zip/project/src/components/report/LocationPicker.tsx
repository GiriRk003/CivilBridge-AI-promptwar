import { useState } from 'react';
import { MapPin, Crosshair } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface LocationPickerProps {
  onLocationSelect: (lat: number, lng: number, label: string) => void;
  onLocationText: (text: string) => void;
  initialText?: string;
}

export function LocationPicker({ onLocationSelect, onLocationText, initialText = '' }: LocationPickerProps) {
  const [locationText, setLocationText] = useState(initialText);
  const [permission, setPermission] = useState<'idle' | 'requesting' | 'granted' | 'denied'>('idle');
  const [error, setError] = useState('');

  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser. Please enter a location manually.');
      return;
    }

    setPermission('requesting');
    setError('');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setPermission('granted');
        const { latitude, longitude } = position.coords;
        const label = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
        onLocationSelect(latitude, longitude, label);
        setLocationText(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
      },
      (err) => {
        setPermission('denied');
        if (err.code === err.PERMISSION_DENIED) {
          setError('Location permission denied. You can enter a location manually below.');
        } else {
          setError('Could not determine your location. Please enter it manually.');
        }
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }
    );
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <MapPin size={18} className="text-slate-400" />
        <input
          type="text"
          value={locationText}
          onChange={(e) => {
            setLocationText(e.target.value);
            onLocationText(e.target.value);
          }}
          placeholder="Enter location manually (e.g. 'Near City Park, Main Street')"
          className="flex-1 rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-100"
          aria-label="Location description"
        />
        <Button
          variant="outline"
          size="md"
          onClick={handleGeolocation}
          disabled={permission === 'requesting'}
        >
          <Crosshair size={16} />
          {permission === 'requesting' ? 'Locating...' : 'Use GPS'}
        </Button>
      </div>
      {permission === 'granted' && (
        <p className="text-xs text-emerald-600">
          Location captured. You can also add a description above.
        </p>
      )}
      {error && (
        <p className="text-xs text-amber-600">{error}</p>
      )}
      <p className="text-xs text-slate-400">
        We will never collect your precise location without your permission.
      </p>
    </div>
  );
}
