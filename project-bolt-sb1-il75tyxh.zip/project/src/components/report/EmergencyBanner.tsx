import { AlertTriangle, Phone } from 'lucide-react';
import type { Severity } from '@/types';

interface EmergencyBannerProps {
  severity: Severity;
  warnings: string[];
}

export function EmergencyBanner({ severity, warnings }: EmergencyBannerProps) {
  if (severity !== 'CRITICAL' && warnings.length === 0) return null;

  const isCritical = severity === 'CRITICAL';

  return (
    <div
      className={`rounded-2xl border-2 p-5 ${
        isCritical
          ? 'border-red-300 bg-red-50'
          : 'border-amber-300 bg-amber-50'
      }`}
      role="alert"
      aria-live="assertive"
    >
      <div className="flex items-start gap-3">
        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
            isCritical ? 'bg-red-100' : 'bg-amber-100'
          }`}
        >
          <AlertTriangle
            size={22}
            className={isCritical ? 'text-red-600' : 'text-amber-600'}
          />
        </div>
        <div className="flex-1">
          <h3
            className={`text-base font-bold ${
              isCritical ? 'text-red-900' : 'text-amber-900'
            }`}
          >
            {isCritical
              ? 'Potential emergency detected'
              : 'Safety warning'}
          </h3>
          <p
            className={`mt-1 text-sm ${
              isCritical ? 'text-red-700' : 'text-amber-700'
            }`}
          >
            AI analysis is not a substitute for emergency services. Move to a safe
            location if possible and contact the appropriate local emergency service.
          </p>
          {warnings.length > 0 && (
            <ul className={`mt-3 space-y-1.5 text-sm ${isCritical ? 'text-red-700' : 'text-amber-700'}`}>
              {warnings.map((w, i) => (
                <li key={i} className="flex items-start gap-2">
                  <AlertTriangle size={14} className="mt-0.5 shrink-0" />
                  <span>{w}</span>
                </li>
              ))}
            </ul>
          )}
          <div
            className={`mt-3 flex items-center gap-2 text-sm font-semibold ${
              isCritical ? 'text-red-800' : 'text-amber-800'
            }`}
          >
            <Phone size={14} />
            Contact your local emergency number if anyone is in danger
          </div>
        </div>
      </div>
    </div>
  );
}
