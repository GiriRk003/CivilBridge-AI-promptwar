import { type ReactNode } from 'react';
import type { Severity, VerificationLabel } from '@/types';

interface BadgeProps {
  children?: ReactNode;
  variant?: 'default' | 'severity' | 'verification' | 'status';
  severity?: Severity;
  verification?: VerificationLabel;
  status?: string;
  className?: string;
}

const severityConfig: Record<Severity, { bg: string; text: string; border: string; icon: string }> = {
  LOW: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', icon: '●' },
  MEDIUM: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', icon: '●' },
  HIGH: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', icon: '●' },
  CRITICAL: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', icon: '●' },
};

const verificationConfig: Record<VerificationLabel, { bg: string; text: string; border: string }> = {
  'USER PROVIDED': { bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200' },
  'AI ANALYZED': { bg: 'bg-violet-50', text: 'text-violet-700', border: 'border-violet-200' },
  VERIFIED: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
  'NOT VERIFIED': { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300' },
};

const statusConfig: Record<string, { bg: string; text: string; border: string }> = {
  Draft: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300' },
  'Ready to Submit': { bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200' },
  Submitted: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  Resolved: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
};

export function Badge({
  children,
  variant = 'default',
  severity,
  verification,
  status,
  className = '',
}: BadgeProps) {
  if (variant === 'severity' && severity) {
    const config = severityConfig[severity];
    return (
      <span
        className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold ${config.bg} ${config.text} ${config.border} ${className}`}
        role="img"
        aria-label={`Severity: ${severity}`}
      >
        <span className={`text-[8px] ${config.text}`}>{config.icon}</span>
        {severity}
      </span>
    );
  }

  if (variant === 'verification' && verification) {
    const config = verificationConfig[verification];
    return (
      <span
        className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${config.bg} ${config.text} ${config.border} ${className}`}
      >
        {verification}
      </span>
    );
  }

  if (variant === 'status' && status) {
    const config = statusConfig[status] ?? statusConfig['Draft'];
    return (
      <span
        className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${config.bg} ${config.text} ${config.border} ${className}`}
      >
        {status}
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-600 ${className}`}
    >
      {children}
    </span>
  );
}
