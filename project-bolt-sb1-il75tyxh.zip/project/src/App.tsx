import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { HomePage } from '@/pages/HomePage';
import { ReportPage } from '@/pages/ReportPage';
import { MyReportsPage } from '@/pages/MyReportsPage';
import { SafetyCenterPage } from '@/pages/SafetyCenterPage';
import { AboutPage } from '@/pages/AboutPage';
import type { Page } from '@/types';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as Page;
      if (['home', 'report', 'my-reports', 'safety', 'about'].includes(hash)) {
        setCurrentPage(hash);
      }
    };
    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      <main className="flex-1">
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'report' && <ReportPage onNavigate={handleNavigate} />}
        {currentPage === 'my-reports' && <MyReportsPage />}
        {currentPage === 'safety' && <SafetyCenterPage />}
        {currentPage === 'about' && <AboutPage onNavigate={handleNavigate} />}
      </main>
      <Footer />
    </div>
  );
}

export default App;
