export type Severity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type ReportStatus = 'Draft' | 'Ready to Submit' | 'Submitted' | 'Resolved';

export type InputMethod = 'text' | 'voice' | 'image';

export type VerificationLabel = 'USER PROVIDED' | 'AI ANALYZED' | 'VERIFIED' | 'NOT VERIFIED';

export interface IncidentAnalysis {
  incidentType: string;
  summary: string;
  severity: Severity;
  confidence: number;
  locationMentioned: string;
  possibleCause: string;
  publicImpact: string;
  immediateSafetyActions: string[];
  recommendedNextSteps: string[];
  authorityCategory: string;
  reportTitle: string;
  reportDescription: string;
  missingInformation: string[];
  warnings: string[];
}

export interface Report {
  id: string;
  incident_type: string;
  summary: string;
  severity: Severity;
  status: ReportStatus;
  location_text: string;
  location_lat: number | null;
  location_lng: number | null;
  analysis: IncidentAnalysis;
  has_image: boolean;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface AnalysisRequest {
  text: string;
  imageBase64?: string;
  imageMimeType?: string;
  demoMode?: boolean;
  demoId?: string;
}

export interface AnalysisResponse {
  success: boolean;
  analysis?: IncidentAnalysis;
  error?: string;
}

export interface DemoIncident {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: Severity;
  imageUrl: string;
  mockAnalysis: IncidentAnalysis;
}

export type Page = 'home' | 'report' | 'my-reports' | 'safety' | 'about';
