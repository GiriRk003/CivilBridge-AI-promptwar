import { createClient } from '@supabase/supabase-js';
import type { Report, IncidentAnalysis } from '@/types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function saveReport(
  analysis: IncidentAnalysis,
  options: {
    locationText?: string;
    locationLat?: number | null;
    locationLng?: number | null;
    hasImage?: boolean;
    isDemo?: boolean;
    status?: string;
  }
): Promise<Report | null> {
  const { data, error } = await supabase
    .from('reports')
    .insert({
      incident_type: analysis.incidentType,
      summary: analysis.summary,
      severity: analysis.severity,
      status: options.status ?? 'Ready to Submit',
      location_text: options.locationText ?? analysis.locationMentioned,
      location_lat: options.locationLat ?? null,
      location_lng: options.locationLng ?? null,
      analysis: analysis as unknown as Record<string, unknown>,
      has_image: options.hasImage ?? false,
      is_demo: options.isDemo ?? false,
    })
    .select()
    .single();

  if (error) {
    console.error('Failed to save report:', error);
    return null;
  }

  return data as unknown as Report;
}

export async function fetchReports(includeDemo = false): Promise<Report[]> {
  let query = supabase
    .from('reports')
    .select('*')
    .order('created_at', { ascending: false });

  if (!includeDemo) {
    query = query.eq('is_demo', false);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Failed to fetch reports:', error);
    return [];
  }

  return (data ?? []) as unknown as Report[];
}

export async function updateReportStatus(
  reportId: string,
  status: string
): Promise<boolean> {
  const { error } = await supabase
    .from('reports')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', reportId);

  if (error) {
    console.error('Failed to update report status:', error);
    return false;
  }

  return true;
}

export async function deleteReport(reportId: string): Promise<boolean> {
  const { error } = await supabase.from('reports').delete().eq('id', reportId);

  if (error) {
    console.error('Failed to delete report:', error);
    return false;
  }

  return true;
}
