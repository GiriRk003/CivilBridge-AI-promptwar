import type { DemoIncident } from '@/types';

export const demoIncidents: DemoIncident[] = [
  {
    id: 'fallen-tree',
    title: 'Fallen Tree Blocking Road',
    description:
      'A large tree has fallen across the main road after heavy rain. Cars cannot pass and traffic is backing up. Some branches are touching power lines.',
    category: 'Road Obstruction',
    severity: 'HIGH',
    imageUrl:
      'https://images.pexels.com/photos/5863389/pexels-photo-5863389.jpeg?auto=compress&cs=tinysrgb&w=800',
    mockAnalysis: {
      incidentType: 'Fallen Tree / Road Obstruction',
      summary:
        'A large tree has fallen across a road, completely blocking traffic. Potential involvement of power lines increases danger.',
      severity: 'HIGH',
      confidence: 0.92,
      locationMentioned: 'Main road (specific road name not provided)',
      possibleCause: 'Severe weather — heavy rain and possible soil loosening',
      publicImpact:
        'Complete road blockage, traffic disruption, potential power line hazard',
      immediateSafetyActions: [
        'Stay away from the fallen tree and any touching power lines',
        'Do not attempt to move the tree yourself',
        'Keep bystanders at a safe distance (at least 10 meters from power lines)',
        'Avoid the area if possible — find alternate routes',
      ],
      recommendedNextSteps: [
        'Contact local municipal authority or roads department',
        'If power lines are involved, contact the electricity utility immediately',
        'Submit a civic report with location and photo evidence',
        'Monitor the area from a safe distance until help arrives',
      ],
      authorityCategory: 'Municipal Corporation / Roads Department',
      reportTitle: 'Fallen tree blocking road with possible power line contact',
      reportDescription:
        'A large tree has fallen across the main road following heavy rainfall, completely obstructing traffic. Branches appear to be in contact with power lines, creating an electrical hazard. Immediate clearance is required to restore traffic flow and address the safety risk.',
      missingInformation: [
        'Exact road name or address',
        'Whether power lines are actively live',
        'Number of affected lanes',
      ],
      warnings: [
        'Do not approach if power lines are involved — treat all downed lines as live',
      ],
    },
  },
  {
    id: 'pothole',
    title: 'Large Pothole',
    description:
      'There is a huge pothole outside my college and two bikes nearly fell. It keeps getting bigger every day.',
    category: 'Road Hazard',
    severity: 'HIGH',
    imageUrl:
      'https://images.pexels.com/photos/2531709/pexels-photo-2531709.jpeg?auto=compress&cs=tinysrgb&w=800',
    mockAnalysis: {
      incidentType: 'Road Hazard — Pothole',
      summary:
        'A large pothole near a college is creating a significant risk for two-wheeler riders, with near-accidents already reported.',
      severity: 'HIGH',
      confidence: 0.88,
      locationMentioned: 'Outside a college (specific name not provided)',
      possibleCause: 'Wear and tear, weather damage, poor road maintenance',
      publicImpact:
        'Risk to two-wheeler riders, potential for accidents and injuries',
      immediateSafetyActions: [
        'Slow down when approaching the area',
        'Warn others about the hazard if safe to do so',
        'Avoid the pothole — do not swerve into oncoming traffic',
      ],
      recommendedNextSteps: [
        'Submit a civic report to the municipal roads department',
        'Attach a photo and precise location',
        'Note the size and depth of the pothole for the report',
        'Follow up on the report status after submission',
      ],
      authorityCategory: 'Municipal Corporation / Roads Department',
      reportTitle: 'Large pothole creating road safety hazard near college',
      reportDescription:
        'A large and growing pothole is located outside a college, posing a significant risk to two-wheeler riders. Two near-accidents have been observed. The pothole is worsening daily and requires urgent repair to prevent injuries.',
      missingInformation: [
        'Exact address or landmark',
        'College name',
        'Pothole dimensions (width and depth)',
      ],
      warnings: [],
    },
  },
  {
    id: 'garbage-overflow',
    title: 'Garbage Overflow',
    description:
      'The garbage bins near the park are overflowing and waste is spreading everywhere. It smells terrible and there are insects everywhere.',
    category: 'Sanitation Issue',
    severity: 'MEDIUM',
    imageUrl:
      'https://images.pexels.com/photos/2673893/pexels-photo-2673893.jpeg?auto=compress&cs=tinysrgb&w=800',
    mockAnalysis: {
      incidentType: 'Sanitation Issue — Garbage Overflow',
      summary:
        'Overflowing garbage bins near a park are creating unsanitary conditions with waste spreading and pest activity.',
      severity: 'MEDIUM',
      confidence: 0.85,
      locationMentioned: 'Near a park (specific name not provided)',
      possibleCause: 'Irregular waste collection, insufficient bin capacity',
      publicImpact:
        'Public health risk, unpleasant environment, pest breeding, potential disease vector',
      immediateSafetyActions: [
        'Avoid direct contact with the waste',
        'Keep children and pets away from the area',
        'Do not burn the waste',
      ],
      recommendedNextSteps: [
        'Submit a civic complaint to the municipal sanitation department',
        'Note the exact location and approximate amount of overflow',
        'Take photos as evidence for the report',
        'Request increased collection frequency for the area',
      ],
      authorityCategory: 'Municipal Sanitation Department',
      reportTitle: 'Overflowing garbage bins near park creating health hazard',
      reportDescription:
        'Garbage bins near a public park are overflowing, with waste spreading into the surrounding area. The situation is attracting insects and creating unsanitary conditions. This poses a public health risk to park visitors and nearby residents.',
      missingInformation: [
        'Exact location or park name',
        'Number of bins affected',
        'Duration of the overflow',
      ],
      warnings: [],
    },
  },
  {
    id: 'flooded-street',
    title: 'Flooded Street',
    description:
      'The entire street near my house is flooded after the rain. Water is entering ground floor homes and cars are stuck.',
    category: 'Flooding',
    severity: 'CRITICAL',
    imageUrl:
      'https://images.pexels.com/photos/1463530/pexels-photo-1463530.jpeg?auto=compress&cs=tinysrgb&w=800',
    mockAnalysis: {
      incidentType: 'Flooding — Street Inundation',
      summary:
        'Severe street flooding is causing water to enter ground-floor homes and trapping vehicles. Immediate risk to residents and property.',
      severity: 'CRITICAL',
      confidence: 0.95,
      locationMentioned: 'Residential street (specific address not provided)',
      possibleCause: 'Heavy rainfall, possible drainage system failure',
      publicImpact:
        'Property damage, vehicles stranded, risk to residents on ground floors, potential electrical hazard',
      immediateSafetyActions: [
        'Move to higher ground if water is rising',
        'Do not walk or drive through flood water — depth and current can be deceptive',
        'Turn off electricity if water is entering your home',
        'Keep emergency contacts ready',
      ],
      recommendedNextSteps: [
        'Contact local emergency services if anyone is in immediate danger',
        'Contact the municipal drainage/flood control department',
        'Document the flooding with photos and timestamps',
        'Submit a civic report with location and severity',
        'Check on vulnerable neighbors if safe to do so',
      ],
      authorityCategory: 'Municipal Drainage Department / Emergency Services',
      reportTitle: 'Severe street flooding with water entering homes',
      reportDescription:
        'A residential street is severely flooded following heavy rainfall. Water has entered ground-floor homes and multiple vehicles are stranded. The flooding poses immediate risk to residents and property. Urgent drainage response and emergency assessment is required.',
      missingInformation: [
        'Exact street address',
        'Water depth',
        'Number of homes affected',
        'Whether anyone needs emergency rescue',
      ],
      warnings: [
        'Potential emergency: If anyone is trapped or in danger, contact emergency services immediately',
        'Do not attempt to walk or drive through flood water',
        'Risk of electrocution if water contacts electrical systems',
      ],
    },
  },
];
