import type { AnalysisRequest, AnalysisResponse, IncidentAnalysis, Severity } from '@/types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const VALID_SEVERITIES: Severity[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

export function validateAnalysis(obj: unknown): obj is IncidentAnalysis {
  if (!obj || typeof obj !== 'object') return false;
  const o = obj as Record<string, unknown>;
  if (typeof o.incidentType !== 'string') return false;
  if (typeof o.summary !== 'string') return false;
  if (!VALID_SEVERITIES.includes(o.severity as Severity)) return false;
  if (typeof o.confidence !== 'number') return false;
  if (typeof o.locationMentioned !== 'string') return false;
  if (typeof o.possibleCause !== 'string') return false;
  if (typeof o.publicImpact !== 'string') return false;
  if (!Array.isArray(o.immediateSafetyActions)) return false;
  if (!Array.isArray(o.recommendedNextSteps)) return false;
  if (typeof o.authorityCategory !== 'string') return false;
  if (typeof o.reportTitle !== 'string') return false;
  if (typeof o.reportDescription !== 'string') return false;
  if (!Array.isArray(o.missingInformation)) return false;
  if (!Array.isArray(o.warnings)) return false;
  return true;
}

export async function analyzeIncident(
  request: AnalysisRequest
): Promise<AnalysisResponse> {
  try {
    const functionUrl = `${supabaseUrl}/functions/v1/gemini-analyze`;

    const response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
      body: JSON.stringify({
        text: request.text,
        imageBase64: request.imageBase64,
        imageMimeType: request.imageMimeType,
        demoMode: request.demoMode,
        demoId: request.demoId,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      console.error('Edge function error:', response.status, errorText);
      return {
        success: false,
        error: 'We couldn\'t analyze that right now. Please try again or describe the problem using text.',
      };
    }

    const data = await response.json();

    if (!data.analysis) {
      return {
        success: false,
        error: data.error || 'The AI could not produce a valid analysis. Please try again.',
      };
    }

    if (!validateAnalysis(data.analysis)) {
      return {
        success: false,
        error: 'The AI response was not in the expected format. Please try again.',
      };
    }

    return { success: true, analysis: data.analysis };
  } catch (err) {
    console.error('Analysis request failed:', err);
    return {
      success: false,
      error: 'We couldn\'t reach the analysis service. Please check your connection and try again.',
    };
  }
}
