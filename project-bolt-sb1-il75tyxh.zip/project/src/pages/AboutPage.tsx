import {
  ShieldCheck,
  Brain,
  Eye,
  FileCheck,
  AlertTriangle,
  Lock,
  Mic,
  Camera,
  PenLine,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import type { Page } from '@/types';

interface AboutPageProps {
  onNavigate: (page: Page) => void;
}

export function AboutPage({ onNavigate }: AboutPageProps) {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-50">
          <ShieldCheck size={28} className="text-sky-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">About CivicBridge AI</h1>
        <p className="mt-3 text-lg text-slate-600">
          A bridge between ordinary people and complex civic systems — powered by AI.
        </p>
      </div>

      <Card className="mb-6 p-6">
        <h2 className="text-xl font-bold text-slate-900">The Problem</h2>
        <p className="mt-3 text-slate-600">
          People encounter civic problems every day — potholes, garbage overflow, flooding,
          fallen trees, safety hazards. But they often don't know what the problem actually is,
          how serious it is, which authority should handle it, or how to communicate it clearly.
        </p>
      </Card>

      <Card className="mb-6 p-6">
        <h2 className="text-xl font-bold text-slate-900">The Solution</h2>
        <p className="mt-3 text-slate-600">
          CivicBridge AI lets you describe a problem through text, voice, or a photo.
          Gemini AI analyzes your input and converts it into a structured, actionable civic report
          with severity assessment, safety guidance, and a ready-to-submit format.
        </p>
        <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          {[
            { label: 'Messy Input', icon: PenLine, color: 'text-slate-500 bg-slate-100' },
            { label: 'Gemini AI', icon: Brain, color: 'text-violet-600 bg-violet-50' },
            { label: 'Structured Report', icon: FileCheck, color: 'text-sky-700 bg-sky-100' },
          ].map((step, i, arr) => {
            const Icon = step.icon;
            return (
              <div key={step.label} className="flex items-center gap-3">
                <div className="flex flex-col items-center gap-2">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${step.color}`}>
                    <Icon size={22} />
                  </div>
                  <span className="text-xs font-semibold text-slate-700">{step.label}</span>
                </div>
                {i < arr.length - 1 && <ArrowRight size={18} className="text-slate-300" />}
              </div>
            );
          })}
        </div>
      </Card>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        {[
          { icon: Mic, title: 'Voice Input', desc: 'Speak naturally about what you saw' },
          { icon: Camera, title: 'Photo Analysis', desc: 'Upload an image for visual analysis' },
          { icon: PenLine, title: 'Text Description', desc: 'Type messy, incomplete descriptions' },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.title} className="p-5">
              <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-sky-50">
                <Icon size={20} className="text-sky-600" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
              <p className="mt-1 text-xs text-slate-600">{item.desc}</p>
            </Card>
          );
        })}
      </div>

      <Card className="mb-6 p-6">
        <h2 className="text-xl font-bold text-slate-900">How It Works</h2>
        <ol className="mt-4 space-y-4">
          {[
            { icon: PenLine, title: 'Describe the problem', desc: 'Use text, voice, or a photo to tell us what happened.' },
            { icon: Brain, title: 'AI analysis', desc: 'Gemini identifies the incident type, severity, cause, and impact.' },
            { icon: AlertTriangle, title: 'Safety guidance', desc: 'Dangerous situations trigger immediate safety warnings and actions.' },
            { icon: Eye, title: 'Verification labels', desc: 'Every piece of information is labeled: User Provided, AI Analyzed, Verified, or Not Verified.' },
            { icon: Zap, title: 'Action plan', desc: 'Get a numbered action plan answering what happened, how serious it is, and what to do.' },
            { icon: FileCheck, title: 'Ready-to-submit report', desc: 'Download or copy a structured civic report to submit to the appropriate authority.' },
          ].map((step, i) => {
            const Icon = step.icon;
            return (
              <li key={i} className="flex gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-100 text-sky-700">
                  <Icon size={16} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">
                    {i + 1}. {step.title}
                  </p>
                  <p className="mt-0.5 text-sm text-slate-600">{step.desc}</p>
                </div>
              </li>
            );
          })}
        </ol>
      </Card>

      <Card className="mb-6 border-amber-200 bg-amber-50 p-6">
        <div className="flex items-start gap-3">
          <AlertTriangle size={22} className="mt-0.5 shrink-0 text-amber-600" />
          <div>
            <h2 className="text-lg font-bold text-amber-900">Anti-Hallucination Commitment</h2>
            <p className="mt-1 text-sm text-amber-700">
              CivicBridge AI will never pretend it has performed an action it hasn't.
              We never claim that services have been contacted, complaints submitted,
              or emergency services dispatched. AI-generated information is always
              labeled as such — never as verified fact.
            </p>
          </div>
        </div>
      </Card>

      <Card className="mb-6 p-6">
        <div className="flex items-start gap-3">
          <Lock size={22} className="mt-0.5 shrink-0 text-slate-600" />
          <div>
            <h2 className="text-lg font-bold text-slate-900">Privacy & Security</h2>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li>• API keys are stored server-side — never exposed in frontend code</li>
              <li>• Images are processed for analysis and not permanently stored unless saved to a report</li>
              <li>• Location is only collected with your explicit permission</li>
              <li>• All user input is validated and sanitized</li>
              <li>• AI responses are validated against a strict schema before display</li>
              <li>• No unnecessary personal information is collected</li>
            </ul>
          </div>
        </div>
      </Card>

      <div className="text-center">
        <Button size="lg" onClick={() => onNavigate('report')}>
          Try It Now
          <ArrowRight size={18} />
        </Button>
      </div>
    </div>
  );
}
