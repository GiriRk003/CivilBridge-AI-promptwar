import { useState, useEffect } from 'react';
import { FolderOpen, Trash2, FileText, MapPin, Calendar, Eye, X } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Spinner } from '@/components/ui/Spinner';
import { EmergencyBanner } from '@/components/report/EmergencyBanner';
import { fetchReports, deleteReport, updateReportStatus } from '@/services/supabase';
import type { Report, ReportStatus } from '@/types';

const statusOptions: ReportStatus[] = ['Draft', 'Ready to Submit', 'Submitted', 'Resolved'];

export function MyReportsPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);

  const load = async () => {
    setLoading(true);
    setError('');
    const data = await fetchReports(true);
    setReports(data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const handleDelete = async (id: string) => {
    const ok = await deleteReport(id);
    if (ok) {
      setReports(reports.filter((r) => r.id !== id));
    }
  };

  const handleStatusChange = async (id: string, status: string) => {
    const ok = await updateReportStatus(id, status);
    if (ok) {
      setReports(reports.map((r) => (r.id === id ? { ...r, status: status as ReportStatus } : r)));
      if (selectedReport?.id === id) {
        setSelectedReport({ ...selectedReport, status: status as ReportStatus });
      }
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <Spinner size={32} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <p className="text-red-600">{error}</p>
        <Button className="mt-4" onClick={load}>Try Again</Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">My Reports</h1>
        <p className="mt-2 text-slate-600">
          View and manage your civic reports. Demo reports are clearly labeled.
        </p>
      </div>

      {reports.length === 0 ? (
        <Card className="p-12 text-center">
          <FolderOpen size={48} className="mx-auto text-slate-300" />
          <h2 className="mt-4 text-lg font-semibold text-slate-700">No reports yet</h2>
          <p className="mt-1 text-sm text-slate-500">
            Reports you create will appear here. Try Demo Mode to see how it works.
          </p>
        </Card>
      ) : (
        <div className="space-y-4">
          {reports.map((report) => (
            <Card key={report.id} className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-semibold text-slate-900">
                      {report.analysis?.reportTitle || report.incident_type}
                    </h3>
                    {report.is_demo && (
                      <Badge className="border-amber-200 bg-amber-50 text-amber-700">DEMO</Badge>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-slate-600">{report.summary}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Calendar size={12} />
                      {new Date(report.created_at).toLocaleDateString(undefined, {
                        year: 'numeric', month: 'short', day: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </span>
                    {report.location_text && (
                      <span className="flex items-center gap-1">
                        <MapPin size={12} />
                        {report.location_text}
                      </span>
                    )}
                    {report.has_image && (
                      <span className="flex items-center gap-1">
                        <FileText size={12} />
                        Has image
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge variant="severity" severity={report.severity} />
                  <Badge variant="status" status={report.status} />
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedReport(report)}
                >
                  <Eye size={14} />
                  View Details
                </Button>
                <select
                  value={report.status}
                  onChange={(e) => handleStatusChange(report.id, e.target.value)}
                  className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                  aria-label="Update report status"
                >
                  {statusOptions.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(report.id)}
                  className="text-red-500 hover:bg-red-50"
                >
                  <Trash2 size={14} />
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Detail Modal */}
      {selectedReport && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => setSelectedReport(null)}
        >
          <div
            className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 flex items-center justify-between border-b border-slate-100 bg-white p-4">
              <h2 className="text-lg font-bold text-slate-900">Report Details</h2>
              <button onClick={() => setSelectedReport(null)} className="text-slate-400 hover:text-slate-600" aria-label="Close">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              {selectedReport.analysis?.warnings?.length > 0 ||
              selectedReport.severity === 'CRITICAL' ? (
                <div className="mb-4">
                  <EmergencyBanner
                    severity={selectedReport.severity}
                    warnings={selectedReport.analysis?.warnings ?? []}
                  />
                </div>
              ) : null}

              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="severity" severity={selectedReport.severity} />
                <Badge variant="status" status={selectedReport.status} />
                {selectedReport.is_demo && (
                  <Badge className="border-amber-200 bg-amber-50 text-amber-700">DEMO</Badge>
                )}
              </div>

              <h3 className="mt-4 text-xl font-bold text-slate-900">
                {selectedReport.analysis?.reportTitle || selectedReport.incident_type}
              </h3>
              <p className="mt-2 text-sm text-slate-600">{selectedReport.summary}</p>

              {selectedReport.analysis && (
                <>
                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    <div>
                      <p className="text-xs font-semibold uppercase text-slate-400">Incident Type</p>
                      <p className="text-sm text-slate-700">{selectedReport.analysis.incidentType}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase text-slate-400">Authority</p>
                      <p className="text-sm text-slate-700">{selectedReport.analysis.authorityCategory}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase text-slate-400">Possible Cause</p>
                      <p className="text-sm text-slate-700">{selectedReport.analysis.possibleCause}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase text-slate-400">Public Impact</p>
                      <p className="text-sm text-slate-700">{selectedReport.analysis.publicImpact}</p>
                    </div>
                  </div>

                  {selectedReport.analysis.immediateSafetyActions?.length > 0 && (
                    <div className="mt-4">
                      <p className="text-xs font-semibold uppercase text-slate-400">Safety Actions</p>
                      <ul className="mt-1 space-y-1">
                        {selectedReport.analysis.immediateSafetyActions.map((a, i) => (
                          <li key={i} className="text-sm text-slate-600">• {a}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {selectedReport.analysis.recommendedNextSteps?.length > 0 && (
                    <div className="mt-4">
                      <p className="text-xs font-semibold uppercase text-slate-400">Next Steps</p>
                      <ul className="mt-1 space-y-1">
                        {selectedReport.analysis.recommendedNextSteps.map((s, i) => (
                          <li key={i} className="text-sm text-slate-600">• {s}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="mt-4">
                    <p className="text-xs font-semibold uppercase text-slate-400">Report Description</p>
                    <p className="mt-1 text-sm text-slate-700">{selectedReport.analysis.reportDescription}</p>
                  </div>

                  {selectedReport.analysis.missingInformation?.length > 0 && (
                    <div className="mt-4">
                      <p className="text-xs font-semibold uppercase text-slate-400">Missing Information</p>
                      <ul className="mt-1 space-y-1">
                        {selectedReport.analysis.missingInformation.map((m, i) => (
                          <li key={i} className="text-sm text-slate-600">• {m}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}

              <div className="mt-4 text-xs text-slate-400">
                Created: {new Date(selectedReport.created_at).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
