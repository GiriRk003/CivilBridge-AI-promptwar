import {
  Mic,
  Camera,
  PenLine,
  ArrowRight,
  ShieldCheck,
  Brain,
  FileCheck,
  MapPin,
  AlertTriangle,
  Zap,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import type { Page } from '@/types';

interface HomePageProps {
  onNavigate: (page: Page) => void;
  onQuickInput?: (method: 'text' | 'voice' | 'image') => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-sky-50 via-white to-white">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-100/40 via-transparent to-transparent" />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-sky-200 bg-sky-50 px-4 py-1.5 text-sm font-medium text-sky-700">
              <ShieldCheck size={16} />
              AI-Powered Civic Assistance
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              Tell us what happened.
              <br />
              <span className="text-sky-600">We'll help you figure out what to do next.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
              Turn a photo, voice message, or simple description into a clear, actionable civic report.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button
                size="xl"
                onClick={() => onNavigate('report')}
                className="w-full sm:w-auto"
              >
                <Mic size={20} />
                Speak
              </Button>
              <Button
                size="xl"
                variant="outline"
                onClick={() => onNavigate('report')}
                className="w-full sm:w-auto"
              >
                <Camera size={20} />
                Upload Photo
              </Button>
              <Button
                size="xl"
                variant="outline"
                onClick={() => onNavigate('report')}
                className="w-full sm:w-auto"
              >
                <PenLine size={20} />
                Describe Problem
              </Button>
            </div>
            <div className="mt-6">
              <Button
                size="lg"
                variant="secondary"
                onClick={() => onNavigate('report')}
              >
                Report an Issue
                <ArrowRight size={18} />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Flow Diagram */}
      <section className="border-y border-slate-100 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <h2 className="text-center text-2xl font-bold text-slate-900 sm:text-3xl">
            From confusion to action.
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-center text-slate-600">
            CivicBridge AI turns messy real-world problems into clear, structured and actionable reports.
          </p>
          <div className="mt-12 flex flex-col items-center gap-3 lg:flex-row lg:justify-center lg:gap-2">
            {[
              { label: 'Messy Input', icon: PenLine, color: 'text-slate-500 bg-slate-100' },
              { label: 'Gemini AI', icon: Brain, color: 'text-violet-600 bg-violet-50' },
              { label: 'Understand', icon: Eye, color: 'text-sky-600 bg-sky-50' },
              { label: 'Verify', icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
              { label: 'Action Plan', icon: Zap, color: 'text-amber-600 bg-amber-50' },
              { label: 'Structured Report', icon: FileCheck, color: 'text-sky-700 bg-sky-100' },
            ].map((step, i, arr) => {
              const Icon = step.icon;
              return (
                <div key={step.label} className="flex items-center gap-2 lg:gap-3">
                  <div className="flex flex-col items-center gap-2">
                    <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${step.color}`}>
                      <Icon size={24} />
                    </div>
                    <span className="text-xs font-semibold text-slate-700">{step.label}</span>
                  </div>
                  {i < arr.length - 1 && (
                    <ArrowRight size={20} className="hidden text-slate-300 lg:block" />
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-10 text-center">
            <p className="text-xl font-semibold text-slate-900">
              One problem. One clear next step.
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[
            {
              icon: Camera,
              title: 'Multimodal Input',
              desc: 'Describe the problem with text, voice, or a photo. CivicBridge handles messy, incomplete descriptions.',
              color: 'text-sky-600 bg-sky-50',
            },
            {
              icon: Brain,
              title: 'AI Analysis',
              desc: 'Gemini identifies the incident type, severity, and potential causes — structured and validated.',
              color: 'text-violet-600 bg-violet-50',
            },
            {
              icon: AlertTriangle,
              title: 'Safety First',
              desc: 'Dangerous situations trigger immediate safety guidance and emergency warnings.',
              color: 'text-red-600 bg-red-50',
            },
            {
              icon: MapPin,
              title: 'Location Aware',
              desc: 'Attach a location to your report manually or with map selection. No silent tracking.',
              color: 'text-emerald-600 bg-emerald-50',
            },
            {
              icon: FileCheck,
              title: 'Ready-to-Submit Reports',
              desc: 'Get a structured civic report with title, description, and recommended authority.',
              color: 'text-amber-600 bg-amber-50',
            },
            {
              icon: Eye,
              title: 'Verification Labels',
              desc: 'Every piece of information is labeled: User Provided, AI Analyzed, Verified, or Not Verified.',
              color: 'text-slate-600 bg-slate-100',
            },
          ].map((feature) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="group rounded-2xl border border-slate-200 bg-white p-6 transition-all hover:border-sky-200 hover:shadow-md"
              >
                <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl ${feature.color}`}>
                  <Icon size={24} />
                </div>
                <h3 className="text-lg font-semibold text-slate-900">{feature.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{feature.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-sky-600 to-sky-800">
        <div className="mx-auto max-w-4xl px-4 py-16 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white">
            Ready to report an issue?
          </h2>
          <p className="mt-3 text-lg text-sky-100">
            It takes less than a minute to turn a problem into an actionable report.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button
              size="xl"
              variant="secondary"
              onClick={() => onNavigate('report')}
              className="bg-white text-sky-700 hover:bg-sky-50"
            >
              Start Reporting
              <ArrowRight size={18} />
            </Button>
            <Button
              size="xl"
              variant="ghost"
              onClick={() => onNavigate('about')}
              className="text-white hover:bg-white/10"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
