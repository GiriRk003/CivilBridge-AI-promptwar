import { useState, useRef, useCallback } from 'react';
import {
  Mic,
  Camera,
  PenLine,
  X,
  Send,
  AlertCircle,
  CheckCircle2,
  ClipboardCopy,
  Download,
  FileText,
  MapPin,
  ShieldAlert,
  ListChecks,
  Info,
  FileCheck,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Spinner } from '@/components/ui/Spinner';
import { EmergencyBanner } from '@/components/report/EmergencyBanner';
import { VerificationTag } from '@/components/report/VerificationTag';
import { LocationPicker } from '@/components/report/LocationPicker';
import { analyzeIncident, validateAnalysis } from '@/services/analysis';
import { saveReport } from '@/services/supabase';
import { demoIncidents } from '@/services/demoIncidents';
import type { IncidentAnalysis, Severity, VerificationLabel, Page } from '@/types';

interface ReportPageProps {
  onNavigate: (page: Page) => void;
}

type InputMode = 'text' | 'voice' | 'image';
type Phase = 'input' | 'analyzing' | 'result' | 'error';

const MAX_IMAGE_SIZE = 10 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export function ReportPage({ onNavigate }: ReportPageProps) {
  const [phase, setPhase] = useState<Phase>('input');
  const [inputMode, setInputMode] = useState<InputMode>('text');
  const [text, setText] = useState('');
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageError, setImageError] = useState('');
  const [analysis, setAnalysis] = useState<IncidentAnalysis | null>(null);
  const [error, setError] = useState('');
  const [locationText, setLocationText] = useState('');
  const [locationLat, setLocationLat] = useState<number | null>(null);
  const [locationLng, setLocationLng] = useState<number | null>(null);
  const [reportSaved, setReportSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showDemoPanel, setShowDemoPanel] = useState(false);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [micPermission, setMicPermission] = useState<'idle' | 'denied' | 'unsupported'>('idle');
  const [transcript, setTranscript] = useState('');
  const recognitionRef = useRef<unknown>(null);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetAll = useCallback(() => {
    setPhase('input');
    setText('');
    setImageBase64(null);
    setImageMimeType('');
    setImagePreview(null);
    setImageError('');
    setAnalysis(null);
    setError('');
    setLocationText('');
    setLocationLat(null);
    setLocationLng(null);
    setReportSaved(false);
    setCopied(false);
    setTranscript('');
    setIsRecording(false);
    setRecordingTime(0);
  }, []);

  const handleImageUpload = (file: File) => {
    setImageError('');

    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      setImageError('Please upload a JPEG, PNG, or WebP image.');
      return;
    }

    if (file.size > MAX_IMAGE_SIZE) {
      setImageError('Image is too large. Maximum size is 10 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setImagePreview(result);

      const base64 = result.split(',')[1] ?? '';
      setImageBase64(base64);
      setImageMimeType(file.type);
    };
    reader.onerror = () => {
      setImageError('Could not read the image file. Please try again.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageUpload(file);
  };

  const removeImage = () => {
    setImageBase64(null);
    setImageMimeType('');
    setImagePreview(null);
    setImageError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Voice recording using Web Speech API
  const startRecording = () => {
    setMicPermission('idle');
    setTranscript('');

    const SpeechRecognition =
      (window as unknown as Record<string, unknown>).SpeechRecognition ||
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMicPermission('unsupported');
      setInputMode('text');
      return;
    }

    const recognition = new (SpeechRecognition as new () => {
      lang: string;
      continuous: boolean;
      interimResults: boolean;
      onresult: (event: { results: { [key: number]: { [key: number]: { transcript: string } } } }) => void;
      onerror: (event: { error: string }) => void;
      onend: () => void;
      start: () => void;
      stop: () => void;
    })();

    recognition.lang = 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event: { results: { [key: number]: { [key: number]: { transcript: string } } } }) => {
      let finalTranscript = '';
      for (let i = 0; i < Object.keys(event.results).length; i++) {
        const result = event.results[i];
        if (result[0]) {
          finalTranscript += result[0].transcript + ' ';
        }
      }
      setTranscript(finalTranscript.trim());
      setText(finalTranscript.trim());
    };

    recognition.onerror = (event: { error: string }) => {
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setMicPermission('denied');
      }
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
        recordingTimerRef.current = null;
      }
    };

    recognition.onend = () => {
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
        recordingTimerRef.current = null;
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
    setRecordingTime(0);
    recordingTimerRef.current = setInterval(() => {
      setRecordingTime((t) => t + 1);
    }, 1000);
  };

  const stopRecording = () => {
    const recognition = recognitionRef.current as { stop: () => void } | null;
    if (recognition) {
      recognition.stop();
    }
    setIsRecording(false);
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleAnalyze = async (demoId?: string, demoText?: string, demoImageBase64?: string) => {
    const inputText = demoText ?? text;
    const inputImage = demoImageBase64 ?? imageBase64;
    const inputMime = demoImageBase64 ? 'image/jpeg' : imageMimeType;

    if (!inputText && !inputImage) {
      setError('Please describe the problem or upload an image first.');
      return;
    }

    setPhase('analyzing');
    setError('');

    const isDemo = !!demoId;

    const response = await analyzeIncident({
      text: inputText,
      imageBase64: inputImage ?? undefined,
      imageMimeType: inputMime || undefined,
      demoMode: isDemo,
      demoId,
    });

    if (!response.success || !response.analysis) {
      setError(response.error || 'Something went wrong. Please try again.');
      setPhase('error');
      return;
    }

    if (!validateAnalysis(response.analysis)) {
      setError('The AI response was not in the expected format. Please try again.');
      setPhase('error');
      return;
    }

    setAnalysis(response.analysis);
    setPhase('result');
  };

  const handleDemoSelect = (demoId: string, demoText: string, demoImageUrl: string) => {
    setText(demoText);
    setImagePreview(demoImageUrl);
    setImageBase64(null);
    setImageMimeType('');

    fetch(demoImageUrl)
      .then((r) => r.blob())
      .then((blob) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          const base64 = result.split(',')[1] ?? '';
          handleAnalyze(demoId, demoText, base64);
        };
        reader.readAsDataURL(blob);
      })
      .catch(() => {
        handleAnalyze(demoId, demoText);
      });
  };

  const handleSaveReport = async () => {
    if (!analysis) return;
    const result = await saveReport(analysis, {
      locationText,
      locationLat,
      locationLng,
      hasImage: !!imageBase64,
      isDemo: false,
      status: 'Ready to Submit',
    });
    if (result) {
      setReportSaved(true);
    } else {
      setError('Could not save the report. Please try again.');
    }
  };

  const handleCopyReport = () => {
    if (!analysis) return;
    const reportText = `CIVIC REPORT
===========
Title: ${analysis.reportTitle}
Incident Type: ${analysis.incidentType}
Severity: ${analysis.severity}
Authority: ${analysis.authorityCategory}
Location: ${locationText || analysis.locationMentioned}

Description:
${analysis.reportDescription}

Immediate Safety Actions:
${analysis.immediateSafetyActions.map((a) => `- ${a}`).join('\n')}

Recommended Next Steps:
${analysis.recommendedNextSteps.map((s) => `- ${s}`).join('\n')}

Missing Information:
${analysis.missingInformation.map((m) => `- ${m}`).join('\n') || 'None'}
`;
    navigator.clipboard.writeText(reportText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleDownloadReport = () => {
    if (!analysis) return;
    const reportText = `CIVIC REPORT\n===========\n\nTitle: ${analysis.reportTitle}\nIncident Type: ${analysis.incidentType}\nSeverity: ${analysis.severity}\nAuthority: ${analysis.authorityCategory}\nLocation: ${locationText || analysis.locationMentioned}\n\nDescription:\n${analysis.reportDescription}\n\nImmediate Safety Actions:\n${analysis.immediateSafetyActions.map((a) => `- ${a}`).join('\n')}\n\nRecommended Next Steps:\n${analysis.recommendedNextSteps.map((s) => `- ${s}`).join('\n')}\n\nMissing Information:\n${analysis.missingInformation.map((m) => `- ${m}`).join('\n') || 'None'}\n`;
    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `civic-report-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const inputMethods: { mode: InputMode; label: string; icon: typeof Mic; desc: string }[] = [
    { mode: 'text', label: 'Describe', icon: PenLine, desc: 'Type what happened' },
    { mode: 'voice', label: 'Speak', icon: Mic, desc: 'Use your microphone' },
    { mode: 'image', label: 'Photo', icon: Camera, desc: 'Upload an image' },
  ];

  // ====== ANALYZING PHASE ======
  if (phase === 'analyzing') {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center gap-6 text-center">
          <div className="relative">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-sky-50">
              <Spinner size={40} />
            </div>
            <div className="absolute -inset-2 animate-pulse rounded-full border-2 border-sky-200" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Analyzing your report</h2>
            <p className="mt-2 text-sm text-slate-500">
              Gemini AI is identifying the incident type, severity, and recommended actions...
            </p>
          </div>
          <div className="flex flex-col gap-2 text-left">
            {['Identifying incident type', 'Assessing severity', 'Extracting details', 'Generating safety actions', 'Creating report'].map((step, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-slate-400">
                <div className="h-2 w-2 rounded-full bg-sky-300 animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />
                {step}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ====== ERROR PHASE ======
  if (phase === 'error') {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8">
        <Card className="p-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-50">
            <AlertCircle size={28} className="text-red-500" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">Something went wrong</h2>
          <p className="mt-2 text-sm text-slate-600">{error}</p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button onClick={() => { setPhase('input'); setError(''); }}>
              Try Again
            </Button>
            <Button variant="outline" onClick={() => setShowDemoPanel(true)}>
              Try Demo Mode
            </Button>
          </div>
        </Card>
        {showDemoPanel && <DemoPanel onSelect={handleDemoSelect} onClose={() => setShowDemoPanel(false)} />}
      </div>
    );
  }

  // ====== RESULT PHASE ======
  if (phase === 'result' && analysis) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Emergency Banner */}
        <div className="mb-6">
          <EmergencyBanner severity={analysis.severity} warnings={analysis.warnings} />
        </div>

        {/* Incident Analysis Card */}
        <Card className="mb-6 overflow-hidden">
          <div className="border-b border-slate-100 bg-slate-50 p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Incident Analysis
                </p>
                <h2 className="mt-1 text-2xl font-bold text-slate-900">
                  {analysis.incidentType}
                </h2>
              </div>
              <Badge variant="severity" severity={analysis.severity} />
            </div>
          </div>
          <div className="p-6">
            <div className="mb-4 flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-700">Summary</h3>
              <VerificationTag label="AI ANALYZED" />
            </div>
            <p className="text-slate-700">{analysis.summary}</p>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Confidence</p>
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="h-2 w-24 overflow-hidden rounded-full bg-slate-200">
                    <div
                      className="h-full rounded-full bg-sky-500"
                      style={{ width: `${Math.round(analysis.confidence * 100)}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-slate-600">
                    {Math.round(analysis.confidence * 100)}%
                  </span>
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Authority</p>
                <p className="mt-1.5 text-sm font-medium text-slate-700">{analysis.authorityCategory}</p>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Possible Cause</p>
                <p className="mt-1.5 text-sm text-slate-700">{analysis.possibleCause}</p>
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Public Impact</p>
                <p className="mt-1.5 text-sm text-slate-700">{analysis.publicImpact}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* What To Do Now */}
        <Card className="mb-6">
          <div className="border-b border-slate-100 p-6">
            <div className="flex items-center gap-2">
              <ShieldAlert size={20} className="text-sky-600" />
              <h3 className="text-lg font-bold text-slate-900">What To Do Now</h3>
            </div>
          </div>
          <div className="p-6">
            <ul className="space-y-3">
              {analysis.immediateSafetyActions.map((action, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-emerald-500" />
                  <span className="text-sm text-slate-700">{action}</span>
                </li>
              ))}
            </ul>
          </div>
        </Card>

        {/* Action Plan */}
        <Card className="mb-6">
          <div className="border-b border-slate-100 p-6">
            <div className="flex items-center gap-2">
              <ListChecks size={20} className="text-sky-600" />
              <h3 className="text-lg font-bold text-slate-900">Action Plan</h3>
            </div>
          </div>
          <div className="p-6">
            <ol className="space-y-4">
              {[
                { q: 'What happened?', a: analysis.summary },
                { q: 'How serious could it be?', a: `${analysis.severity} — ${analysis.publicImpact}` },
                { q: 'What should I do immediately?', a: analysis.immediateSafetyActions.join('. ') },
                { q: 'Who should handle this?', a: analysis.authorityCategory },
                { q: 'What information is still missing?', a: analysis.missingInformation.length > 0 ? analysis.missingInformation.join('. ') : 'No critical information missing.' },
                { q: 'What should I include in my report?', a: `Title: "${analysis.reportTitle}". ${analysis.reportDescription}` },
              ].map((item, i) => (
                <li key={i} className="flex gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sky-100 text-sm font-bold text-sky-700">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{item.q}</p>
                    <p className="mt-0.5 text-sm text-slate-600">{item.a}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </Card>

        {/* Ready-to-Submit Report */}
        <Card className="mb-6 overflow-hidden">
          <div className="border-b border-slate-100 bg-sky-50 p-6">
            <div className="flex items-center gap-2">
              <FileCheck size={20} className="text-sky-600" />
              <h3 className="text-lg font-bold text-slate-900">Ready-to-Submit Report</h3>
            </div>
          </div>
          <div className="p-6 space-y-5">
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Title</p>
                <VerificationTag label="AI ANALYZED" />
              </div>
              <p className="mt-1 font-semibold text-slate-900">{analysis.reportTitle}</p>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Description</p>
                <VerificationTag label="AI ANALYZED" />
              </div>
              <p className="mt-1 text-sm text-slate-700">{analysis.reportDescription}</p>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Location</p>
                <VerificationTag label={locationText ? 'USER PROVIDED' : 'NOT VERIFIED'} />
              </div>
              <p className="mt-1 text-sm text-slate-700">
                {locationText || analysis.locationMentioned || 'No location provided'}
              </p>
            </div>
            {imagePreview && (
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Evidence</p>
                  <VerificationTag label="USER PROVIDED" />
                </div>
                <img
                  src={imagePreview}
                  alt="Uploaded evidence"
                  className="mt-2 max-h-48 rounded-xl border border-slate-200 object-cover"
                />
              </div>
            )}
            <div className="flex flex-wrap gap-3 pt-2">
              <Button variant="outline" size="md" onClick={handleCopyReport}>
                <ClipboardCopy size={16} />
                {copied ? 'Copied!' : 'Copy Report'}
              </Button>
              <Button variant="outline" size="md" onClick={handleDownloadReport}>
                <Download size={16} />
                Download Report
              </Button>
            </div>
          </div>
        </Card>

        {/* Missing Info */}
        {analysis.missingInformation.length > 0 && (
          <Card className="mb-6">
            <div className="p-6">
              <div className="flex items-center gap-2">
                <Info size={18} className="text-amber-500" />
                <h3 className="text-sm font-semibold text-slate-900">Missing Information</h3>
              </div>
              <ul className="mt-3 space-y-2">
                {analysis.missingInformation.map((info, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400" />
                    {info}
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        )}

        {/* Save & Navigation */}
        <div className="flex flex-col gap-3 sm:flex-row sm:justify-between">
          <div className="flex gap-3">
            <Button variant="outline" onClick={resetAll}>
              <Trash2 size={16} />
              New Report
            </Button>
          </div>
          <div className="flex gap-3">
            {reportSaved ? (
              <div className="flex items-center gap-2 text-sm font-medium text-emerald-600">
                <CheckCircle2 size={18} />
                Report saved to My Reports
              </div>
            ) : (
              <Button onClick={handleSaveReport}>
                <FileText size={16} />
                Save to My Reports
              </Button>
            )}
            <Button variant="secondary" onClick={() => onNavigate('my-reports')}>
              View My Reports
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ====== INPUT PHASE ======
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-slate-900">Report an Issue</h1>
        <p className="mt-2 text-slate-600">
          Describe what happened. We'll help you figure out what to do next.
        </p>
      </div>

      {/* Input mode tabs */}
      <div className="mb-6 grid grid-cols-3 gap-2">
        {inputMethods.map((method) => {
          const Icon = method.icon;
          const isActive = inputMode === method.mode;
          return (
            <button
              key={method.mode}
              onClick={() => setInputMode(method.mode)}
              className={`flex flex-col items-center gap-2 rounded-2xl border-2 p-4 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                isActive
                  ? 'border-sky-500 bg-sky-50 text-sky-700'
                  : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
              }`}
              aria-pressed={isActive}
            >
              <Icon size={24} />
              <span className="text-sm font-semibold">{method.label}</span>
            </button>
          );
        })}
      </div>

      {/* Text input */}
      {inputMode === 'text' && (
        <Card className="p-6">
          <label htmlFor="description" className="mb-2 block text-sm font-semibold text-slate-700">
            Describe what happened...
          </label>
          <textarea
            id="description"
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={6}
            placeholder="Example: There is a large pothole near my college and traffic is getting difficult."
            className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-100 resize-none"
          />
          <p className="mt-2 text-xs text-slate-400">
            Natural language is fine. Incomplete or messy descriptions work too.
          </p>
        </Card>
      )}

      {/* Voice input */}
      {inputMode === 'voice' && (
        <Card className="p-6">
          {micPermission === 'unsupported' && (
            <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
              Voice input is not supported in this browser. Please use text input instead.
            </div>
          )}
          {micPermission === 'denied' && (
            <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
              Microphone permission was denied. Please allow microphone access or use text input.
            </div>
          )}

          <div className="flex flex-col items-center gap-4">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              className={`flex h-20 w-20 items-center justify-center rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                isRecording
                  ? 'bg-red-500 hover:bg-red-600'
                  : 'bg-sky-600 hover:bg-sky-700'
              }`}
              aria-label={isRecording ? 'Stop recording' : 'Start recording'}
            >
              <Mic size={32} className="text-white" />
            </button>

            {isRecording && (
              <div className="flex items-center gap-2 text-sm text-red-600">
                <span className="flex h-2.5 w-2.5 animate-pulse rounded-full bg-red-500" />
                Recording... {formatTime(recordingTime)}
              </div>
            )}

            {!isRecording && (
              <p className="text-sm text-slate-500">
                {isRecording ? 'Tap to stop' : 'Tap to start recording'}
              </p>
            )}

            {transcript && (
              <div className="w-full">
                <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Transcript
                </p>
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                  {transcript}
                </div>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Image input */}
      {inputMode === 'image' && (
        <Card className="p-6">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleFileChange}
            className="hidden"
            id="image-upload"
          />
          {!imagePreview ? (
            <label
              htmlFor="image-upload"
              className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-slate-300 p-12 transition-colors hover:border-sky-400 hover:bg-sky-50"
            >
              <Camera size={40} className="text-slate-400" />
              <div className="text-center">
                <p className="text-sm font-semibold text-slate-700">Click to upload an image</p>
                <p className="mt-1 text-xs text-slate-400">JPEG, PNG, or WebP — max 10 MB</p>
              </div>
            </label>
          ) : (
            <div>
              <div className="relative">
                <img
                  src={imagePreview}
                  alt="Uploaded preview"
                  className="max-h-64 w-full rounded-xl object-cover"
                />
                <button
                  onClick={removeImage}
                  className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
                  aria-label="Remove image"
                >
                  <X size={16} />
                </button>
              </div>
              <p className="mt-2 text-xs text-slate-400">
                Image is processed locally and not stored permanently.
              </p>
            </div>
          )}
          {imageError && (
            <div className="mt-3 flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-600">
              <AlertCircle size={16} />
              {imageError}
            </div>
          )}
          <div className="mt-4">
            <label htmlFor="image-description" className="mb-2 block text-sm font-semibold text-slate-700">
              Add a description (optional)
            </label>
            <textarea
              id="image-description"
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              placeholder="Describe what's in the image..."
              className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-100 resize-none"
            />
          </div>
        </Card>
      )}

      {/* Location */}
      <Card className="mt-6 p-6">
        <div className="mb-3 flex items-center gap-2">
          <MapPin size={18} className="text-slate-400" />
          <h3 className="text-sm font-semibold text-slate-700">Location (optional)</h3>
        </div>
        <LocationPicker
          onLocationSelect={(lat, lng, label) => {
            setLocationLat(lat);
            setLocationLng(lng);
            setLocationText(label);
          }}
          onLocationText={setLocationText}
          initialText={locationText}
        />
      </Card>

      {/* Error */}
      {error && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">
          <AlertCircle size={18} />
          {error}
        </div>
      )}

      {/* Analyze Button */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Button
          variant="ghost"
          onClick={() => setShowDemoPanel(!showDemoPanel)}
        >
          <Sparkles size={16} />
          {showDemoPanel ? 'Hide Demo' : 'Demo Mode'}
        </Button>
        <Button
          size="lg"
          onClick={() => handleAnalyze()}
          disabled={!text && !imageBase64}
        >
          <Send size={18} />
          Analyze with AI
        </Button>
      </div>

      {/* Demo Panel */}
      {showDemoPanel && <DemoPanel onSelect={handleDemoSelect} onClose={() => setShowDemoPanel(false)} />}
    </div>
  );
}

function DemoPanel({
  onSelect,
  onClose,
}: {
  onSelect: (id: string, text: string, imageUrl: string) => void;
  onClose: () => void;
}) {
  return (
    <Card className="mt-4 overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-100 bg-amber-50 p-4">
        <div className="flex items-center gap-2">
          <Sparkles size={18} className="text-amber-600" />
          <h3 className="text-sm font-bold text-slate-900">Demo Mode — Try a sample incident</h3>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600" aria-label="Close demo panel">
          <X size={18} />
        </button>
      </div>
      <div className="p-4">
        <p className="mb-3 text-xs text-slate-500">
          Demo Mode uses pre-built sample data to show the full workflow. These are clearly labeled as demo reports and are separate from real user reports.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          {demoIncidents.map((incident) => (
            <button
              key={incident.id}
              onClick={() => onSelect(incident.id, incident.description, incident.imageUrl)}
              className="group flex items-start gap-3 rounded-xl border border-slate-200 p-3 text-left transition-all hover:border-sky-300 hover:bg-sky-50"
            >
              <img
                src={incident.imageUrl}
                alt={incident.title}
                className="h-16 w-16 shrink-0 rounded-lg object-cover"
              />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">{incident.title}</p>
                <p className="mt-0.5 text-xs text-slate-500 line-clamp-2">{incident.description}</p>
                <div className="mt-1.5">
                  <Badge variant="severity" severity={incident.severity} />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </Card>
  );
}
