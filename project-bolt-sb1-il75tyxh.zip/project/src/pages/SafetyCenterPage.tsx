import {
  Flame,
  Waves,
  Zap,
  Truck,
  AlertTriangle,
  Phone,
  HeartPulse,
  Wind,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { Card } from '@/components/ui/Card';

const emergencyTypes = [
  {
    icon: Flame,
    title: 'Fire',
    color: 'text-red-600 bg-red-50',
    steps: [
      'Get out immediately — do not collect belongings',
      'Stay low to avoid smoke inhalation',
      'Call your local fire emergency number',
      'Do not use elevators',
      'If trapped, signal from a window',
    ],
  },
  {
    icon: Waves,
    title: 'Flooding',
    color: 'text-blue-600 bg-blue-50',
    steps: [
      'Move to higher ground immediately',
      'Do not walk or drive through flood water',
      'Turn off electricity if safe to do so',
      'Avoid downed power lines',
      'Keep emergency contacts ready',
    ],
  },
  {
    icon: Zap,
    title: 'Electrical Hazard',
    color: 'text-amber-600 bg-amber-50',
    steps: [
      'Do not touch affected equipment or wires',
      'Keep others away from the area',
      'Turn off power at the main breaker if safe',
      'Contact the electricity utility',
      'Do not use water near electrical hazards',
    ],
  },
  {
    icon: Truck,
    title: 'Road Accident',
    color: 'text-orange-600 bg-orange-50',
    steps: [
      'Check for injuries — do not move seriously injured people',
      'Move to a safe location away from traffic',
      'Call for emergency medical help if needed',
      'Turn on hazard lights and set up warning signals',
      'Do not leave the scene until help arrives',
    ],
  },
  {
    icon: HeartPulse,
    title: 'Medical Emergency',
    color: 'text-pink-600 bg-pink-50',
    steps: [
      'Call your local emergency medical number',
      'Check if the person is breathing and responsive',
      'Do not give food or water to an unconscious person',
      'Apply basic first aid if trained to do so',
      'Stay with the person until help arrives',
    ],
  },
  {
    icon: Wind,
    title: 'Severe Weather',
    color: 'text-sky-600 bg-sky-50',
    steps: [
      'Seek shelter indoors immediately',
      'Stay away from windows and exterior walls',
      'Avoid using electrical appliances',
      'Keep emergency supplies ready',
      'Monitor local weather alerts if available',
    ],
  },
];

export function SafetyCenterPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-red-50">
          <ShieldCheck size={28} className="text-red-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Safety Center</h1>
        <p className="mt-2 text-slate-600">
          Essential safety guidance for common emergencies. This is general information,
          not a substitute for professional emergency services.
        </p>
      </div>

      <Card className="mb-8 border-red-200 bg-red-50 p-6">
        <div className="flex items-start gap-3">
          <AlertTriangle size={24} className="mt-0.5 shrink-0 text-red-600" />
          <div>
            <h2 className="text-lg font-bold text-red-900">Important</h2>
            <p className="mt-1 text-sm text-red-700">
              CivicBridge AI is a tool to help you understand and report civic issues.
              It is NOT a substitute for emergency services. If you or someone else is in
              immediate danger, contact your local emergency number right away.
            </p>
            <div className="mt-3 flex items-center gap-2 text-sm font-semibold text-red-800">
              <Phone size={16} />
              Know your local emergency number and keep it accessible
            </div>
          </div>
        </div>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {emergencyTypes.map((type) => {
          const Icon = type.icon;
          return (
            <Card key={type.title} className="overflow-hidden">
              <div className="border-b border-slate-100 p-5">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${type.color}`}>
                    <Icon size={20} />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{type.title}</h3>
                </div>
              </div>
              <div className="p-5">
                <ul className="space-y-2.5">
                  {type.steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-500" />
                      <span className="text-sm text-slate-700">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="mt-8 p-6">
        <h2 className="text-lg font-bold text-slate-900">General Safety Principles</h2>
        <ul className="mt-4 space-y-3">
          {[
            'Stay calm and assess the situation before acting',
            'Prioritize your own safety before helping others',
            'Keep your phone charged and emergency contacts saved',
            'Know the locations of nearby hospitals and emergency services',
            'Report dangerous situations to authorities even if they seem minor',
            'Document incidents with photos when safe to do so',
          ].map((principle, i) => (
            <li key={i} className="flex items-start gap-2.5">
              <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-sky-500" />
              <span className="text-sm text-slate-700">{principle}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
