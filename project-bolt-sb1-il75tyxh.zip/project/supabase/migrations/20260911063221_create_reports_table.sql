/*
# Create reports table for CivicBridge AI

1. New Tables
- `reports` — stores civic incident reports created by users
  - `id` (uuid, primary key)
  - `incident_type` (text, e.g. "Road Hazard", "Fire", "Garbage Overflow")
  - `summary` (text, short AI-generated summary)
  - `severity` (text, LOW | MEDIUM | HIGH | CRITICAL)
  - `status` (text, Draft | Ready to Submit | Submitted | Resolved)
  - `location_text` (text, user-provided location description)
  - `location_lat` (float8, optional latitude)
  - `location_lng` (float8, optional longitude)
  - `analysis` (jsonb, full structured AI analysis response)
  - `has_image` (boolean, whether an image was attached)
  - `is_demo` (boolean, whether this is a demo-mode report)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

2. Security
- Enable RLS on `reports`.
- Allow anon + authenticated CRUD — this is a no-auth civic reporting app where all reports are publicly viewable.
- `USING (true)` is acceptable because the data is intentionally shared/public (community civic reports).

3. Notes
- No user_id column — this is a single-tenant no-auth app.
- Reports are community-visible so citizens can see what issues have been reported.
- Demo reports are flagged with `is_demo = true` to separate them from real reports.
*/

CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_type text NOT NULL DEFAULT 'Unknown',
  summary text NOT NULL DEFAULT '',
  severity text NOT NULL DEFAULT 'LOW' CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  status text NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft', 'Ready to Submit', 'Submitted', 'Resolved')),
  location_text text DEFAULT '',
  location_lat double precision,
  location_lng double precision,
  analysis jsonb NOT NULL DEFAULT '{}'::jsonb,
  has_image boolean NOT NULL DEFAULT false,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_reports" ON reports;
CREATE POLICY "anon_select_reports" ON reports FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reports" ON reports;
CREATE POLICY "anon_insert_reports" ON reports FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_reports" ON reports;
CREATE POLICY "anon_update_reports" ON reports FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_reports" ON reports;
CREATE POLICY "anon_delete_reports" ON reports FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_severity ON reports (severity);
CREATE INDEX IF NOT EXISTS idx_reports_is_demo ON reports (is_demo);
