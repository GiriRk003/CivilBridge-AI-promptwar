import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GEMINI_MODEL = "gemini-2.0-flash";
const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY") ?? "";

const SYSTEM_PROMPT = `You are CivicBridge AI, a civic emergency and assistance analysis system.

Your job is to analyze user-provided text and/or images about civic issues and produce a structured incident analysis.

CRITICAL RULES:
1. NEVER invent or hallucinate facts. If you cannot determine something, say "Unable to determine."
2. NEVER fabricate emergency phone numbers, addresses, government department names, weather conditions, or traffic conditions.
3. NEVER claim that any service has been contacted or dispatched.
4. Clearly distinguish between what the user described and what you are inferring.
5. For potentially dangerous situations (fire, gas leak, accident, violence, electrical, flooding, medical), include appropriate safety warnings.
6. Use "Recommended action" or "AI assessment" language — never claim verified facts.
7. Be conservative: if something might be dangerous, treat it as potentially dangerous.

You must respond with ONLY a valid JSON object matching this exact schema:
{
  "incidentType": "string - category of the incident",
  "summary": "string - one or two sentence summary of the situation",
  "severity": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "confidence": "number 0-1 - your confidence in this analysis",
  "locationMentioned": "string - any location info the user provided, or 'Unable to determine'",
  "possibleCause": "string - likely cause, or 'Unable to determine'",
  "publicImpact": "string - who/what is affected",
  "immediateSafetyActions": ["array of strings - what to do right now for safety"],
  "recommendedNextSteps": ["array of strings - what to do next"],
  "authorityCategory": "string - type of authority/service that should handle this (e.g. 'Municipal Roads Department', 'Fire Department', 'Sanitation Department')",
  "reportTitle": "string - a clear, concise title for a civic report",
  "reportDescription": "string - a formal description suitable for submitting to authorities",
  "missingInformation": ["array of strings - what important info is missing"],
  "warnings": ["array of strings - safety warnings if applicable, empty if none"]
}

Severity guidelines:
- CRITICAL: Immediate danger to life, health, or property (fire, flooding entering homes, gas leak, structural collapse)
- HIGH: Significant risk or disruption (large pothole, road blockage, dangerous infrastructure)
- MEDIUM: Notable issue affecting community (garbage overflow, streetlight outage, water leak)
- LOW: Minor nuisance or cosmetic issue

Respond with ONLY the JSON object. No markdown, no explanation, no code fences.`;

interface AnalysisRequest {
  text: string;
  imageBase64?: string;
  imageMimeType?: string;
  demoMode?: boolean;
  demoId?: string;
}

interface IncidentAnalysis {
  incidentType: string;
  summary: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  confidence: number;
  locationMentioned: string;
  possibleCause: string;
  publicImpact: string;
  immediateSafetyActions: string[];
  recommendedNextSteps: string[];
  authorityCategory: string;
  reportTitle: string;
  reportDescription: string;
  missingInformation: string[];
  warnings: string[];
}

const DEMO_ANALYSES: Record<string, IncidentAnalysis> = {
  "fallen-tree": {
    incidentType: "Fallen Tree / Road Obstruction",
    summary:
      "A large tree has fallen across a road, completely blocking traffic. Potential involvement of power lines increases danger.",
    severity: "HIGH",
    confidence: 0.92,
    locationMentioned: "Main road (specific road name not provided)",
    possibleCause: "Severe weather — heavy rain and possible soil loosening",
    publicImpact:
      "Complete road blockage, traffic disruption, potential power line hazard",
    immediateSafetyActions: [
      "Stay away from the fallen tree and any touching power lines",
      "Do not attempt to move the tree yourself",
      "Keep bystanders at a safe distance (at least 10 meters from power lines)",
      "Avoid the area if possible — find alternate routes",
    ],
    recommendedNextSteps: [
      "Contact local municipal authority or roads department",
      "If power lines are involved, contact the electricity utility immediately",
      "Submit a civic report with location and photo evidence",
      "Monitor the area from a safe distance until help arrives",
    ],
    authorityCategory: "Municipal Corporation / Roads Department",
    reportTitle: "Fallen tree blocking road with possible power line contact",
    reportDescription:
      "A large tree has fallen across the main road following heavy rainfall, completely obstructing traffic. Branches appear to be in contact with power lines, creating an electrical hazard. Immediate clearance is required to restore traffic flow and address the safety risk.",
    missingInformation: [
      "Exact road name or address",
      "Whether power lines are actively live",
      "Number of affected lanes",
    ],
    warnings: [
      "Do not approach if power lines are involved — treat all downed lines as live",
    ],
  },
  pothole: {
    incidentType: "Road Hazard — Pothole",
    summary:
      "A large pothole near a college is creating a significant risk for two-wheeler riders, with near-accidents already reported.",
    severity: "HIGH",
    confidence: 0.88,
    locationMentioned: "Outside a college (specific name not provided)",
    possibleCause: "Wear and tear, weather damage, poor road maintenance",
    publicImpact:
      "Risk to two-wheeler riders, potential for accidents and injuries",
    immediateSafetyActions: [
      "Slow down when approaching the area",
      "Warn others about the hazard if safe to do so",
      "Avoid the pothole — do not swerve into oncoming traffic",
    ],
    recommendedNextSteps: [
      "Submit a civic report to the municipal roads department",
      "Attach a photo and precise location",
      "Note the size and depth of the pothole for the report",
      "Follow up on the report status after submission",
    ],
    authorityCategory: "Municipal Corporation / Roads Department",
    reportTitle: "Large pothole creating road safety hazard near college",
    reportDescription:
      "A large and growing pothole is located outside a college, posing a significant risk to two-wheeler riders. Two near-accidents have been observed. The pothole is worsening daily and requires urgent repair to prevent injuries.",
    missingInformation: [
      "Exact address or landmark",
      "College name",
      "Pothole dimensions (width and depth)",
    ],
    warnings: [],
  },
  "garbage-overflow": {
    incidentType: "Sanitation Issue — Garbage Overflow",
    summary:
      "Overflowing garbage bins near a park are creating unsanitary conditions with waste spreading and pest activity.",
    severity: "MEDIUM",
    confidence: 0.85,
    locationMentioned: "Near a park (specific name not provided)",
    possibleCause: "Irregular waste collection, insufficient bin capacity",
    publicImpact:
      "Public health risk, unpleasant environment, pest breeding, potential disease vector",
    immediateSafetyActions: [
      "Avoid direct contact with the waste",
      "Keep children and pets away from the area",
      "Do not burn the waste",
    ],
    recommendedNextSteps: [
      "Submit a civic complaint to the municipal sanitation department",
      "Note the exact location and approximate amount of overflow",
      "Take photos as evidence for the report",
      "Request increased collection frequency for the area",
    ],
    authorityCategory: "Municipal Sanitation Department",
    reportTitle: "Overflowing garbage bins near park creating health hazard",
    reportDescription:
      "Garbage bins near a public park are overflowing, with waste spreading into the surrounding area. The situation is attracting insects and creating unsanitary conditions. This poses a public health risk to park visitors and nearby residents.",
    missingInformation: [
      "Exact location or park name",
      "Number of bins affected",
      "Duration of the overflow",
    ],
    warnings: [],
  },
  "flooded-street": {
    incidentType: "Flooding — Street Inundation",
    summary:
      "Severe street flooding is causing water to enter ground-floor homes and trapping vehicles. Immediate risk to residents and property.",
    severity: "CRITICAL",
    confidence: 0.95,
    locationMentioned: "Residential street (specific address not provided)",
    possibleCause: "Heavy rainfall, possible drainage system failure",
    publicImpact:
      "Property damage, vehicles stranded, risk to residents on ground floors, potential electrical hazard",
    immediateSafetyActions: [
      "Move to higher ground if water is rising",
      "Do not walk or drive through flood water — depth and current can be deceptive",
      "Turn off electricity if water is entering your home",
      "Keep emergency contacts ready",
    ],
    recommendedNextSteps: [
      "Contact local emergency services if anyone is in immediate danger",
      "Contact the municipal drainage/flood control department",
      "Document the flooding with photos and timestamps",
      "Submit a civic report with location and severity",
      "Check on vulnerable neighbors if safe to do so",
    ],
    authorityCategory: "Municipal Drainage Department / Emergency Services",
    reportTitle: "Severe street flooding with water entering homes",
    reportDescription:
      "A residential street is severely flooded following heavy rainfall. Water has entered ground-floor homes and multiple vehicles are stranded. The flooding poses immediate risk to residents and property. Urgent drainage response and emergency assessment is required.",
    missingInformation: [
      "Exact street address",
      "Water depth",
      "Number of homes affected",
      "Whether anyone needs emergency rescue",
    ],
    warnings: [
      "Potential emergency: If anyone is trapped or in danger, contact emergency services immediately",
      "Do not attempt to walk or drive through flood water",
      "Risk of electrocution if water contacts electrical systems",
    ],
  },
};

function validateAnalysis(obj: unknown): obj is IncidentAnalysis {
  if (!obj || typeof obj !== "object") return false;
  const o = obj as Record<string, unknown>;
  const validSeverities = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];
  return (
    typeof o.incidentType === "string" &&
    typeof o.summary === "string" &&
    typeof o.severity === "string" &&
    validSeverities.includes(o.severity) &&
    typeof o.confidence === "number" &&
    typeof o.locationMentioned === "string" &&
    typeof o.possibleCause === "string" &&
    typeof o.publicImpact === "string" &&
    Array.isArray(o.immediateSafetyActions) &&
    Array.isArray(o.recommendedNextSteps) &&
    typeof o.authorityCategory === "string" &&
    typeof o.reportTitle === "string" &&
    typeof o.reportDescription === "string" &&
    Array.isArray(o.missingInformation) &&
    Array.isArray(o.warnings)
  );
}

function sanitizeAnalysis(analysis: IncidentAnalysis): IncidentAnalysis {
  return {
    incidentType: String(analysis.incidentType || "Unknown").slice(0, 200),
    summary: String(analysis.summary || "").slice(0, 1000),
    severity: ["LOW", "MEDIUM", "HIGH", "CRITICAL"].includes(analysis.severity)
      ? analysis.severity
      : "LOW",
    confidence:
      typeof analysis.confidence === "number" && analysis.confidence >= 0 && analysis.confidence <= 1
        ? analysis.confidence
        : 0.5,
    locationMentioned: String(analysis.locationMentioned || "Unable to determine").slice(0, 500),
    possibleCause: String(analysis.possibleCause || "Unable to determine").slice(0, 500),
    publicImpact: String(analysis.publicImpact || "Unable to determine").slice(0, 1000),
    immediateSafetyActions: (Array.isArray(analysis.immediateSafetyActions)
      ? analysis.immediateSafetyActions
      : []).map((s) => String(s).slice(0, 500)).slice(0, 20),
    recommendedNextSteps: (Array.isArray(analysis.recommendedNextSteps)
      ? analysis.recommendedNextSteps
      : []).map((s) => String(s).slice(0, 500)).slice(0, 20),
    authorityCategory: String(analysis.authorityCategory || "Unable to determine").slice(0, 300),
    reportTitle: String(analysis.reportTitle || "Untitled Report").slice(0, 300),
    reportDescription: String(analysis.reportDescription || "").slice(0, 3000),
    missingInformation: (Array.isArray(analysis.missingInformation)
      ? analysis.missingInformation
      : []).map((s) => String(s).slice(0, 500)).slice(0, 20),
    warnings: (Array.isArray(analysis.warnings) ? analysis.warnings : []).map((s) =>
      String(s).slice(0, 500)
    ).slice(0, 20),
  };
}

async function callGemini(
  text: string,
  imageBase64?: string,
  imageMimeType?: string
): Promise<IncidentAnalysis> {
  const parts: Array<Record<string, unknown>> = [{ text: SYSTEM_PROMPT }];

  if (text) {
    parts.push({ text: `User input: ${text}` });
  }

  if (imageBase64 && imageMimeType) {
    parts.push({
      inline_data: {
        mime_type: imageMimeType,
        data: imageBase64,
      },
    });
  }

  const requestBody = {
    contents: [{ parts }],
    generationConfig: {
      temperature: 0.4,
      topP: 0.8,
      maxOutputTokens: 2048,
      responseMimeType: "application/json",
    },
  };

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
    }
  );

  if (!response.ok) {
    const errorText = await response.text().catch(() => "Unknown error");
    throw new Error(`Gemini API error (${response.status}): ${errorText}`);
  }

  const data = await response.json();
  const candidate = data?.candidates?.[0];
  const content = candidate?.content?.parts?.[0]?.text;

  if (!content) {
    throw new Error("Gemini returned no content");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      parsed = JSON.parse(jsonMatch[0]);
    } else {
      throw new Error("Could not parse Gemini response as JSON");
    }
  }

  if (!validateAnalysis(parsed)) {
    throw new Error("Gemini response failed schema validation");
  }

  return sanitizeAnalysis(parsed as IncidentAnalysis);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: AnalysisRequest = await req.json();
    const { text, imageBase64, imageMimeType, demoMode, demoId } = body;

    if (demoMode && demoId && DEMO_ANALYSES[demoId]) {
      return new Response(
        JSON.stringify({ success: true, analysis: DEMO_ANALYSES[demoId] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!text && !imageBase64) {
      return new Response(
        JSON.stringify({
          success: false,
          error: "Please provide a text description or an image to analyze.",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!GEMINI_API_KEY) {
      return new Response(
        JSON.stringify({
          success: false,
          error: "AI analysis is not configured. Please use Demo Mode to see the full workflow.",
        }),
        {
          status: 503,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const analysis = await callGemini(text, imageBase64, imageMimeType);

    return new Response(
      JSON.stringify({ success: true, analysis }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("gemini-analyze error:", message);

    return new Response(
      JSON.stringify({
        success: false,
        error:
          "We couldn't analyze that right now. Please try again or describe the problem using text.",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
